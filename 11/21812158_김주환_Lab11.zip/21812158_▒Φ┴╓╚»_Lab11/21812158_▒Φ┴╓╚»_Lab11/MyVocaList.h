/* MyVocaList.h */
#ifndef MY_VOCA_LIST_H
#define MY_VOCA_LIST_H
int NUM_MY_TOEIC_VOCA = 13;
MyVoca myToeicVocaList[]; // defined in MyVocaList.cpp
#endif