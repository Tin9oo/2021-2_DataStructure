/* SimParam.h */
#define TOTAL_NUM_DATA 20
#define MAX_ROUNDS 1000
#define QUEUE_SIZE 10