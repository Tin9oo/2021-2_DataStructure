/* SimParam.h */
#ifndef SP_H
#define SP_H
#define MAX_ROUND 100
#define NUM_DATA 16
#endif // !SP_H
